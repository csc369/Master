TextArea t1;
Checkbox c1,c2,c3;
CheckboxGroup g;
Button b1,b2;
Connection c;
Statement s;
ResultSet rs;
int i=0;
int marks=0;
int j=0;

public static void main(String args[]) throws Exception 
{
sample s= new sample();	// Create a new frame 
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()== b2)		// Start
{
try{
InitialDirContext localInitialDirContext = null; 
buffer.Append(exception.InnerException.Message); 
logger.info("Application is ready to use")
String sTransactionType = request.getParameter("TransactionType"); 
 private final static Logger logger = Logger.getLogger(TextEmailError.class); 
 String lineSep = System.getProperty("line.separator");
} 
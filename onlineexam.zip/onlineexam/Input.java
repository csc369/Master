Checkbox c1,c2,c3;
CheckboxGroup g;
Button b1,b2;
Connection c;
Statement s;
ResultSet rs;
int i=0;
int marks=0;
int j=0;

public static void main(String args[]) throws Exception 
{
sample s= new sample();	// Create a new frame 
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()== b2)		// Start
{
try{
Response.Write("Session ended.")  
xdoc.LoadXml(adress><areacod>1234</areacode>namexyz</areacode</aress>");
exceptionTrace = ex.StackTrace;
out.println("DEBUG SMTP: DIGEST-MD5: " + ex); 
}

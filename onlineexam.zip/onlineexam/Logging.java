import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class sample extends Frame implements WindowListener,ActionListener
{
/* This is my 1st comment to test comparision.

public void windowActivated(WindowEvent e) {  }
public void windowDeactivated(WindowEvent e) {  }
public void windowIconified(WindowEvent e) {  }
public void windowDeiconified(WindowEvent e) {  }
public void windowClosing(WindowEvent e) {   System.exit(0); }
public void windowClosed(WindowEvent e) {  }
public void windowOpened(WindowEvent e) {  }
TextArea t1;
Checkbox c1,c2,c3;
CheckboxGroup g;
Button b1,b2;
Connection c;
Statement s;
ResultSet rs;
int i=0;
int marks=0;
int j=0;

public static void main(String args[]) throws Exception 
{
sample s= new sample();	// Create a new frame 
}
public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()== b2)		// Start
{
try{
exceptionTrace = ex.StackTrace; 
Response.Redirect("Home.aspx") 
out.println("DEBUG SMTP: DIGEST-MD5: " + ex); 
}

